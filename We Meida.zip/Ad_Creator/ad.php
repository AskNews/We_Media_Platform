<?php
$type="ad";
include 'includes/header.php';
?>
<?php
echo $type;
?>


<?php
include 'includes/footer.php';
?>