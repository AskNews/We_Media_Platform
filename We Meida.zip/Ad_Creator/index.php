<?php
$type="index";
include 'includes/header.php';
?>
<?php
echo $type;
?>


<?php
include 'includes/footer.php';
?>