<?php
include "includes/header.php";
?>
<?php
include "manager/news/manager_manage_news.php";
?>
<?php
include "includes/footer.php";
?>