<div class="row clearfix">
<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
		<div class="card">
			<div class="header bg-amber">
				<h2>
					Monetization rules <small>Description text here...</small>
				</h2>
			</div>
			<div class="body">
				- If your menitization is enabled then your content post limit is 3
				otherwise is it is 1 <br/><br/>
				- Register days > 7 <br/><br/>
				- Index Point > 40 
			</div>
		</div>
	</div>
</div>
<div class="row clearfix">
	<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
		<div class="card">
			<div class="header bg-grey">
				<h2>
					For Content Post <small>Description text here...</small>
				</h2>
			</div>
			<div class="body">
				If 3 news  publish successfully in one month then
			</div>
		</div>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
		<div class="card">
			<div class="header bg-cyan">
				<h2>
					For Follower<small>Description text here...</small>
				</h2>
			</div>
			<div class="body">
				> 40 followers required in one month 
			</div>
		</div>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
		<div class="card">
			<div class="header bg-red">
				<h2>
					For likes <small>Description text here...</small>
				</h2>
			</div>
			<div class="body">
				> 100 likes required on 1 one news in one month
			</div>
		</div>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
		<div class="card">
			<div class="header bg-pink">
				<h2>
					For Views <small>Description text here...</small>
				</h2>
			</div>
			<div class="body">
				> 100 views required on 1 one news in one month
			</div>
		</div>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
		<div class="card">
			<div class="header bg-green">
				<h2>
					For Index Point <small>Description text here...</small>
				</h2>
			</div>
			<div class="body">
				If all above criteria are fullfill then index point is incresed by (+5)
			</div>
		</div>
	</div>
</div>

<div class="row clearfix">
	<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
		<div class="card">
			<div class="header bg-orange">
				<h2>
					For Spam news <small>Description text here...</small>
				</h2>
			</div>
			<div class="body">
				If your news is reported then index point is decresed by (-5)
			</div>
		</div>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
		<div class="card">
			<div class="header bg-red">
				<h2>
					Platform Rules <small>Description text here...</small>
				</h2>
			</div>
			<div class="body">
				- No copyright contents<br/>
				- If user does unneccassary action then it might be block
			</div>
		</div>
	</div>
	
	
</div>

