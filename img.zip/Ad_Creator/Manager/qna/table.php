
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">QNA</div>
                                    <div class="card-body">
                                    <button style="text-align:left;" type="button" class="btn btn-outline-primary btn-lg active">How can i create news?</button>  
                                    <input id="ans1" name="ans1" type="text" class="form-control btn-lg" aria-required="true" value="create account as a Content Creator">
                                    </div>

                                    <div class="card-body">
                                    <button style="text-align:left;" type="button" class="btn btn-outline-primary btn-lg active">How can i create news? </button>  
                                    <input id="ans1" name="ans1" type="text" class="form-control btn-lg" aria-required="true" value="create account as a Content Creator">
                                    </div>  
                                </div>
                             </div>
                        </div>
                    </div>
                </div>
