                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">

                        <div class="col-md-4">
                                <div class="card bg-danger">
                                    <div class="card-body">
                                        <blockquote class="blockquote mb-0">
                                            <p class="text-light">user must select appropreate ads with relative category.</p>
                                            <footer class="blockquote-footer text-light">
                                                <cite title="Source Title"></cite>
                                            </footer>
                                         </blockquote>
                                     </div>
                                 </div>
                             </div>

                             <div class="col-md-4">
                                <div class="card">
                                    <div class="card-header bg-secondary">
                                        <strong class="card-title text-light">First Advertise</strong>
                                    </div>
                                    <div class="card-body bg-danger">
                                        <p class="text-light"> User must need to setup their ad creator account with payment details befor creating first advertise.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-header bg-secondary">
                                        <strong class="card-title text-light">FOr create Advertise</strong>
                                    </div>
                                    <div class="card-body bg-danger">
                                        <p class="text-light">You must have minimum 2000rs in your wallate to create your advertise..
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="card bg-danger">
                                    <div class="card-body">
                                        <blockquote class="blockquote mb-0">
                                            <p class="text-light">platform has rights to remove or disable your advertise</p>
                                            <footer class="blockquote-footer text-light">
                                                <cite title="Source Title"></cite>
                                            </footer>
                                         </blockquote>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
